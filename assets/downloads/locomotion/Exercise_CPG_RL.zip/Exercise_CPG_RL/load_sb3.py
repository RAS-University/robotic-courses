# SPDX-FileCopyrightText: Copyright (c) 2022 Guillaume Bellegarda. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the conditions of the BSD 3-Clause license are met.
# The full licence text is reproduced in env/hopf_network.py.
#
# Copyright (c) 2022 EPFL, Guillaume Bellegarda

"""
PART 5: load a trained policy and see what it learned.

Set LOG_DIR below to the folder run_sb3.py printed when it finished, then run:

    python load_sb3.py

The numbers printed at the end are the ones to compare against Part 4: average
speed and Cost of Transport, measured the same way, so the comparison is fair.
"""

import os
import numpy as np
from matplotlib import pyplot as plt

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_util import make_vec_env

from utils.file_utils import get_latest_model
from env.quadruped_gym_env import QuadrupedGymEnv

# ----------------------------------------------------------------------------------
# [TODO 11] Point this at your own training run (run_sb3.py prints the path).
LOG_DIR = './logs/intermediate_models/REPLACE_ME/'
# ----------------------------------------------------------------------------------

TEST_STEPS = 2000
DES_VEL_X = 1.0   # the velocity you trained for, used for the tracking plot

env_config = {"motor_control_mode": "CPG",
              "task_env": "LR_COURSE_TASK",
              "observation_space_mode": "LR_COURSE_OBS",
              "render": True,
              "record_video": False,
              "add_noise": False}   # try True once it works: noise it never saw

if not os.path.isdir(LOG_DIR):
    raise SystemExit(f"LOG_DIR does not exist: {LOG_DIR}\n"
                     f"Set it to the folder printed by run_sb3.py (TODO 11).")

stats_path = os.path.join(LOG_DIR, "vec_normalize.pkl")
model_name = get_latest_model(LOG_DIR)

env = lambda: QuadrupedGymEnv(**env_config)
env = make_vec_env(env, n_envs=1)
env = VecNormalize.load(stats_path, env)
env.training = False     # do not update normalisation statistics at test time
env.norm_reward = False

model = PPO.load(model_name, env)
print("\nLoaded", model_name, "\n")

# ----------------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------------
speed_log = np.zeros(TEST_STEPS)
reward_log = np.zeros(TEST_STEPS)
r_log = np.zeros((TEST_STEPS, 4))
theta_log = np.zeros((TEST_STEPS, 4))
mu_rl_log = np.zeros((TEST_STEPS, 4))
omega_rl_log = np.zeros((TEST_STEPS, 4))
contact_log = np.zeros((TEST_STEPS, 4))
energy = 0.0

obs = env.reset()
episode_reward = 0

for i in range(TEST_STEPS):
    action, _ = model.predict(obs, deterministic=True)
    obs, rewards, dones, info = env.step(action)
    episode_reward += rewards

    base_env = env.envs[0].env
    cpg = base_env._cpg

    # [TODO 12] Fill the logs. The CPG state is available through `cpg`
    # (get_r(), get_theta(), and the policy-set _mu_rl / _omega_rl), and the robot
    # through `base_env.robot` (GetBaseLinearVelocity(), GetContactInfo()[3]).
    # Follow the same pattern you used in run_cpg.py.
    speed_log[i] = 0.0        # [TODO 12]
    reward_log[i] = 0.0       # [TODO 12]
    r_log[i, :] = 0.0         # [TODO 12]
    theta_log[i, :] = 0.0     # [TODO 12]
    mu_rl_log[i, :] = 0.0     # [TODO 12]
    omega_rl_log[i, :] = 0.0  # [TODO 12]
    contact_log[i, :] = 0.0   # [TODO 12]

    for tau, vel in zip(base_env._dt_motor_torques, base_env._dt_motor_velocities):
        energy += np.abs(np.dot(tau, vel)) * base_env._time_step

    if dones:
        print("episode reward", episode_reward, " final base position", info[0]['base_pos'])
        episode_reward = 0
        obs = env.reset()

# ----------------------------------------------------------------------------------
# Results
# ----------------------------------------------------------------------------------
base_pos = env.envs[0].env.robot.GetBasePosition()
distance = np.sqrt(base_pos[0] ** 2 + base_pos[1] ** 2)
mass = sum(env.envs[0].env.robot.GetTotalMassFromURDF())
cot = energy / (mass * 9.81 * distance) if distance > 1e-6 else float('nan')

print("\n" + "=" * 52)
print(f" average speed       {np.mean(speed_log):.3f} m/s   (target {DES_VEL_X})")
print(f" distance travelled  {distance:.2f} m")
print(f" Cost of Transport   {cot:.3f}")
print("=" * 52 + "\n")

# [TODO 13] Make the plots. Four that are worth having:
#   1. speed against time, with a horizontal line at DES_VEL_X  (does it track?)
#   2. the amplitudes mu and frequencies omega the policy commanded  (what did it choose?)
#   3. the CPG phases theta                                     (did the gait survive?)
#   4. a contact diagram: contact_log as an image, legs on the vertical axis
#      (plt.imshow(contact_log.T, aspect='auto') is enough) -- this shows you which
#      gait actually emerged, and you can compare it directly with Part 4.
