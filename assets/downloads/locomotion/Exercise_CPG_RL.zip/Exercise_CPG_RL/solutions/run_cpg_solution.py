# SPDX-FileCopyrightText: Copyright (c) 2022 Guillaume Bellegarda. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the conditions of the BSD 3-Clause license are met.
# The full licence text is reproduced in env/hopf_network.py.
#
# Copyright (c) 2022 EPFL, Guillaume Bellegarda

"""
REFERENCE SOLUTION for Part 4.

PART 4: run the CPG on the A1 quadruped.

The CPG you completed in env/hopf_network.py produces a desired foot position for
each leg. This script closes the loop: it converts those foot positions into joint
torques and sends them to the robot.

Two contributions make up the torque on each leg:

  1. a joint-space PD term, which needs inverse kinematics to know the target angles
  2. a Cartesian-space PD term, which needs the leg Jacobian

The second one is the interesting one for this course: it is Virtual Model Control
from section 8.3.3.3, with the leg behaving as though a spring and damper were
attached between the actual and the desired foot position.

Run with:  python run_cpg.py
"""

import time
import numpy as np
import matplotlib
from matplotlib import pyplot as plt

from env.hopf_network import HopfNetwork
from env.quadruped_gym_env import QuadrupedGymEnv

# ----------------------------------------------------------------------------------
# Settings you are meant to change
# ----------------------------------------------------------------------------------
GAIT = "TROT"            # TROT, WALK, PACE or BOUND
ADD_CARTESIAN_PD = True  # turn the Cartesian PD term on or off
TEST_SECONDS = 10        # how long to simulate

TIME_STEP = 0.001
foot_y = 0.0838                      # hip length (m)
sideSign = np.array([-1, 1, -1, 1])  # body right is negative

# joint PD gains
kp = np.array([100, 100, 100])
kd = np.array([2, 2, 2])

# Cartesian PD gains
kpCartesian = np.diag([500] * 3)
kdCartesian = np.diag([20] * 3)

# ----------------------------------------------------------------------------------
env = QuadrupedGymEnv(render=True,
                      on_rack=False,           # True is useful for debugging: robot hangs in the air
                      isRLGymInterface=False,  # not using RL here
                      time_step=TIME_STEP,
                      action_repeat=1,
                      motor_control_mode="TORQUE",
                      add_noise=False,
                      record_video=False)

cpg = HopfNetwork(time_step=TIME_STEP, gait=GAIT)

TEST_STEPS = int(TEST_SECONDS / TIME_STEP)
t = np.arange(TEST_STEPS) * TIME_STEP

# ----------------------------------------------------------------------------------
# Logging (already set up for you: just fill the arrays in the loop)
# ----------------------------------------------------------------------------------
r_log = np.zeros((TEST_STEPS, 4))
theta_log = np.zeros((TEST_STEPS, 4))
foot_des_log = np.zeros((TEST_STEPS, 3))   # desired foot position, front-right leg
foot_act_log = np.zeros((TEST_STEPS, 3))   # actual foot position,  front-right leg
speed_log = np.zeros(TEST_STEPS)
energy = 0.0

for j in range(TEST_STEPS):
    action = np.zeros(12)

    # desired foot positions from the CPG
    xs, zs = cpg.update()

    # SOLUTION
    q = env.robot.GetMotorAngles()
    dq = env.robot.GetMotorVelocities()

    for i in range(4):
        tau = np.zeros(3)

        # desired foot position of leg i, expressed in that leg's frame
        leg_xyz = np.array([xs[i], sideSign[i] * foot_y, zs[i]])

        # SOLUTION
        leg_q = env.robot.ComputeInverseKinematics(i, leg_xyz)

        # SOLUTION
        tau += kp * (leg_q - q[3 * i: 3 * i + 3]) + kd * (0 - dq[3 * i: 3 * i + 3])

        if ADD_CARTESIAN_PD:
            # SOLUTION: Jacobian and foot position at the measured joint angles
            J, foot_pos = env.robot.ComputeJacobianAndPosition(i, q[3 * i: 3 * i + 3])

            # SOLUTION: foot velocity in the leg frame
            foot_vel = J @ dq[3 * i: 3 * i + 3]

            # SOLUTION: virtual spring-damper on the foot, mapped through J^T
            F = kpCartesian @ (leg_xyz - foot_pos) + kdCartesian @ (np.zeros(3) - foot_vel)
            tau += J.T @ F

        action[3 * i: 3 * i + 3] = tau

    env.step(action)

    # accumulate mechanical energy, for the Cost of Transport
    for tau_vec, vel_vec in zip(env._dt_motor_torques, env._dt_motor_velocities):
        energy += np.abs(np.dot(np.asarray(tau_vec), np.asarray(vel_vec))) * TIME_STEP

    # log
    r_log[j, :] = cpg.get_r()
    theta_log[j, :] = cpg.get_theta()
    foot_des_log[j, :] = np.array([xs[0], sideSign[0] * foot_y, zs[0]])
    _, foot_act_log[j, :] = env.robot.ComputeJacobianAndPosition(0, q[0:3])
    v = env.robot.GetBaseLinearVelocity()
    speed_log[j] = np.sqrt(v[0] ** 2 + v[1] ** 2)

# ----------------------------------------------------------------------------------
# Results
# ----------------------------------------------------------------------------------
base_pos = env.robot.GetBasePosition()
distance = np.sqrt(base_pos[0] ** 2 + base_pos[1] ** 2)
mass = sum(env.robot.GetTotalMassFromURDF())   # every link, not just the trunk
g = 9.81
cot = energy / (mass * g * distance) if distance > 1e-6 else float('nan')

print("\n" + "=" * 52)
print(f" gait                {GAIT}")
print(f" Cartesian PD        {'on' if ADD_CARTESIAN_PD else 'off'}")
print(f" distance travelled  {distance:.2f} m")
print(f" average speed       {np.mean(speed_log):.3f} m/s")
print(f" energy used         {energy:.1f} J")
print(f" Cost of Transport   {cot:.3f}")
print("=" * 52 + "\n")

fig, ax = plt.subplots(2, 2, figsize=(12, 7))

ax[0, 0].plot(t, r_log)
ax[0, 0].set_title("CPG amplitudes $r_i$")
ax[0, 0].set_xlabel("time (s)")
ax[0, 0].legend(["FR", "FL", "RR", "RL"], loc="upper right", fontsize=8)

ax[0, 1].plot(t, theta_log)
ax[0, 1].set_title(r"CPG phases $\theta_i$")
ax[0, 1].set_xlabel("time (s)")

ax[1, 0].plot(t, foot_des_log[:, 0], label="desired x")
ax[1, 0].plot(t, foot_act_log[:, 0], label="actual x", alpha=0.8)
ax[1, 0].plot(t, foot_des_log[:, 2], label="desired z")
ax[1, 0].plot(t, foot_act_log[:, 2], label="actual z", alpha=0.8)
ax[1, 0].set_title("Front-right foot, desired vs actual")
ax[1, 0].set_xlabel("time (s)")
ax[1, 0].set_ylabel("position (m)")
ax[1, 0].legend(fontsize=8)

ax[1, 1].plot(t, speed_log)
ax[1, 1].set_title("Base speed (m/s)")
ax[1, 1].set_xlabel("time (s)")

fig.suptitle(f"{GAIT}, Cartesian PD {'on' if ADD_CARTESIAN_PD else 'off'}, CoT = {cot:.3f}")
fig.tight_layout()
plt.show()
