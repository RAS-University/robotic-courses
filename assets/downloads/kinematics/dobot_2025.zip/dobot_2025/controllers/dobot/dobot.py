# dobot.py
#
# Sample Webots controller file for driving the Dobot robot
# arm model.

# No copyright, 2022, Garth Zeglin.  This file is
# explicitly placed in the public domain.

print("loading dobot.py...")

# Import standard Python modules.
import math

import numpy as np
import matplotlib.pyplot as plt


# Import the Webots simulator API.
from controller import Robot

# Define the time step in milliseconds between controller updates.
EVENT_LOOP_DT = 200

def deg2rad(deg):
    return deg*(math.pi/180.0)

def rad2deg(rad):
    return rad*(180.0/math.pi)

################################################################
# The sample controller is defined as an class which is then instanced as a
# singleton control object.  This is conventional Python practice and also
# simplifies the implementation of the Arduino interface which connects this
# code to physical hardware.

class Dobot(Robot):
    def __init__(self):

        # Initialize the superclass which implements the Robot API.
        super().__init__()

        robot_name = self.getName()
        print("%s: controller connected." % (robot_name))

        # Define kinematic properties of arm.  This should be kept in sync with
        # the simulation geometry.  The following numbers are close to those derived from
        # observations of the Dobot controller.
        self.L1 = 150.0  # 149.8
        self.L2 = 150.0  # 148.0
        self.X0 =  90.0  # 92.8
        self.Z0 =   0.0  # 0.1

        # Fetch handles for the four axis motors.
        j1 = self.getDevice('motor1')
        j2 = self.getDevice('motor2')
        j3 = self.getDevice('motor3')
        j4 = self.getDevice('motor4')

        # Convenience list of all actuators.
        self.motors = [j1, j2, j3, j4]

        # Fetch handle for suction cup 'connector'.
        self.suction = self.getDevice('suction')
        self.suction.enablePresence(EVENT_LOOP_DT)

        # Initialize pose generators.
        # self.position = self.position_gen()
        self.position = self.cycle_gen()
        
        # for manipulability logging
        self.time_list = []
        self.detJ_list = []
        
        return

    #================================================================
    def forward_kinematics(self, j1, j2, j3, j4):
        """Compute the tool center point (TCP) position and rotation of the
        Dobot, accepting four joint angles in radians and returning a (x, y, z,
        r) tuple with the TCP position in millimeters and rotation in radians.
        """
        ### ==============================================================================
        # COMPLETE THESE LINES OF CODE
        # 1. Compute the planar “radius” from joint 2 & 3:
        rad = __________           # e.g. self.X0 + self.L1*… + self.L2*…
        # 2. Compute the height of the TCP above the ground plane:
        z   = __________           # e.g. self.Z0 + self.L1*… – self.L2*…
        # 3. Compute the XY position of the TCP by rotating the radial distance using J1
        x   = __________           # rad * cos(j1)
        y   = __________           # rad * sin(j1)
        # 4. TCP frame rotation is determined entirely by J1 and J4:
        rot = __________           # combine j1 and j4
        ### ==============================================================================

        return x, y, z, rot

    #================================================================
    def inverse_kinematics(self, x, y, z, r):
        """
        Compute the robot joint angles given a TCP location and rotation.

        Args:
            x, y, z: Desired TCP coordinates (mm).
            r: Desired TCP rotation angle (rad).

        Returns:
            (j1, j2, j3, j4): Tuple of computed joint angles (rad).
        """
        ### ==============================================================================
        # COMPLETE THESE LINES OF CODE
        # 1. Planar radius and base rotation (j1) ---
        # Compute radial distance from robot base to TCP projected on XY plane.
        rad = __________  

        # Base joint angle (j1) towards target point.
        j1 = __________  

        # 2. End-effector rotation (j4) ---
        # Adjust TCP rotation relative to base rotation.
        j4 = __________  # r - j1

        # 3. Adjust offsets for solving 2-link planar IK ---
        # Horizontal (dr) and vertical (dz) offsets from base to TCP.
        dr = __________  
        dz = __________  

        # 4. Solve planar IK using polar coordinates ---
        # Distance squared and actual radius from base to TCP.
        radiussq = __________  
        radius   = __________ 

        # Polar angle (gamma) towards the target in vertical plane.
        gamma = __________   

        # 5. Apply Law of Cosines (compute elbow angle β) ---
        # Compute argument for acos, ensuring it's within [-1, 1].
        acosarg = (radiussq - self.L1**2 - self.L2**2) / (-2 * self.L1 * self.L2)
        if acosarg < -1.0:  beta = math.pi
        elif acosarg > 1.0: beta = 0.0
        else:               beta = math.acos(acosarg)

        # Clamp acosarg between [-1, 1] to prevent errors:
        acosarg = max(min(acosarg, 1.0), -1.0)

        # Compute elbow angle (β) using acos.
        beta = __________  # acos(acosarg)

        # 6: Apply Law of Sines (compute shoulder angle α) ---
        # Use radius and beta to compute shoulder angle (α).
        # Avoid division by zero:
        if radius > 0.0:
            alpha = __________  # asin(L2 * sin(beta) / radius)
        else:
            alpha = 0.0

        # 7: Final joint angles (j2, j3) ---
        j2 = __________  
        j3 = __________  
        ### ==============================================================================


        return j1, j2, j3, j4
        
    # cycle of poses to move a block back and forth
    def cycle_gen(self):
        home_pose = [0.0, 0.0, 0.0, 0.0]
        grasp1_pose = self.inverse_kinematics(250.0, 0.0, -46.0, 0.0) # xyzr
        print("IK grasp1 solution radians:", grasp1_pose)
        print("IK grasp1 solution degrees:", [rad2deg(a) for a in grasp1_pose])

        lift1_pose  = self.inverse_kinematics(250.0, 0.0, -26.0, 0.0) # xyzr

        x2 = 300.0
        y2 =  0.0
        grasp2_pose = self.inverse_kinematics(x2, y2, -46.0, 0.0) # xyzr
        lift2_pose  = self.inverse_kinematics(x2, y2, -26.0, 0.0) # xyzr

        while True:
            yield home_pose
            yield lift1_pose
            yield grasp1_pose
            self.suction.lock()
            yield lift1_pose
            yield lift2_pose
            yield grasp2_pose
            self.suction.unlock()
            yield lift2_pose

            yield home_pose
            yield lift2_pose
            yield grasp2_pose
            self.suction.lock()
            yield lift2_pose
            yield lift1_pose
            yield grasp1_pose
            self.suction.unlock()
            yield lift1_pose

    #================================================================
    def set_targets(self, pose):
        """Convenience function to set all joint targets."""
        for joint, angle in zip(self.motors, pose):
            joint.setPosition(angle)

    def run(self):
        iteration_count = 5
        cycle_count = iteration_count

        while robot.step(EVENT_LOOP_DT) != -1:

            # Read simulator clock time.
            t = robot.getTime()
            print("Suction presence:", self.suction.getPresence())
    
            # Change the target position in a cycle with a two-second period.
            # Change the target position in a cycle with a two-second period.
            cycle_count -= 1
            if cycle_count <= 0:
                cycle_count = iteration_count
                angles = next(self.position)
                print(f"Moving to {angles}")
                self.set_targets(angles)
                j1,j2,j3,j4 = angles
                J = self.compute_jacobian(j1, j2, j3)
                detJ = np.linalg.det(J)
                self.time_list.append(self.getTime())
                self.detJ_list.append(detJ)
                cycle_count += 1
                print(cycle_count)
                

################################################################
# If running directly from Webots as a script, the following will begin execution.
# This will have no effect when this file is imported as a module.
if __name__ == "__main__":
    robot = Dobot()
    robot.run()
