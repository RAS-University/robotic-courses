# Programming Exercises 4 and 5: CPG and CPG-RL on a quadruped

Course 8.3, *Overview of Control Approaches*.

You will make a Unitree A1 quadruped walk in PyBullet, twice over. First with a
Central Pattern Generator alone, which is the bio-inspired family of section 8.3.5.
Then by putting a learned policy on top of that same CPG, which is the hybrid
architecture of section 8.3.6, and which is the point of the whole exercise.

---

## 1. Setup

Python 3.9 or newer. A separate environment is strongly recommended, because the
dependencies here differ from the earlier practicals.

```bash
# with conda (recommended)
conda create -n quadruped python=3.9
conda activate quadruped

# or with venv
python -m venv venv
source venv/bin/activate      # Linux / macOS
venv\Scripts\activate         # Windows
```

Then:

```bash
pip install -r requirements.txt
```

If `pybullet` fails to build, install it through conda first and then re-run the
`pip install`:

```bash
conda install conda-forge::pybullet
```

Check the install by running `python run_cpg.py`. The simulator window should open
and the robot should collapse in a heap, because you have not written the controller
yet. That is the correct starting point.

---

## 2. What is in here

```text
Exercise_CPG_RL/
├── env/
│   ├── hopf_network.py        <-- PART 4: TODO 1, 2, 3   (and TODO 8 for Part 5)
│   ├── quadruped_gym_env.py   <-- PART 5: TODO 9, 10
│   ├── quadruped.py               robot interface: read this, do not modify
│   ├── quadruped_motor.py         motor model
│   └── configs_a1.py              robot constants, gains, joint limits
├── a1_description/                URDF and meshes for the A1
├── utils/                         file and callback helpers
├── run_cpg.py                 <-- PART 4: TODO 4, 5, 6, 7
├── run_sb3.py                     PART 5: training, already configured
├── load_sb3.py                <-- PART 5: TODO 11, 12, 13
├── solutions/                     reference solutions, for after you have tried
└── requirements.txt
```

`env/quadruped.py` is the file to read before you start. It has everything you will
call: `GetMotorAngles`, `GetMotorVelocities`, `ComputeInverseKinematics`,
`ComputeJacobianAndPosition`, `GetBaseLinearVelocity`, `GetContactInfo`.

There are no automatic checks. You judge your own work by whether the robot walks,
and by the numbers and plots the scripts print.

---

## 3. Part 4: the CPG

Work in this order. Nothing later will work until the earlier steps do.

| TODO | File | What |
|---|---|---|
| 1 | `env/hopf_network.py` | the four gait coupling matrices |
| 2 | `env/hopf_network.py` | the Hopf equations and their integration |
| 3 | `env/hopf_network.py` | mapping oscillator state to foot positions |
| 4 | `run_cpg.py` | read joint angles and velocities |
| 5 | `run_cpg.py` | inverse kinematics |
| 6 | `run_cpg.py` | joint PD torque |
| 7 | `run_cpg.py` | Cartesian PD torque, through the Jacobian transpose |

**TODO 1 — the coupling matrices.** Watch the sign convention. The exercise is worth
doing carefully because it is the claim of Figure 18 in the course page made
concrete: the coupling weights *are* the gait. Get the sign backwards and TROT,
PACE and BOUND still look right, because their offsets are 0 or ±π where the sign
cannot be seen. WALK is the one that will catch you.

**TODO 2 — the oscillator.** Two things happen here. The amplitude converges to
√µ regardless of where it starts, which is the stable limit cycle of Figure 16.
The phase advances at one of two rates depending on whether the leg is in swing or
in stance, which is where the duty factor comes from.

**TODO 7 — the Jacobian transpose.** This is Virtual Model Control, from section
8.3.3.3. You are placing an imaginary spring and damper between where the foot is
and where the CPG says it should be, and computing the joint torques that reproduce
that force. The same **Jᵀ** you used in Exercise 3.

### What to hand in for Part 4

Run each of the four gaits and fill in this table:

| gait | average speed (m/s) | Cost of Transport |
|---|---|---|
| TROT | | |
| WALK | | |
| PACE | | |
| BOUND | | |

Two notes so you know whether you are on track.

The oscillator amplitudes start from a fixed random seed, so **the same code gives
the same numbers every time**. If you change a gain and the result changes, that is
the gain, not luck. If you want to check how sensitive your controller is, pass a
different `seed=` to `HopfNetwork` and run it again.

With the default gains, TROT, WALK and PACE should all walk, at roughly 0.6 to
0.8 m/s with a Cost of Transport somewhere between 0.3 and 0.8. **BOUND will barely
move with the default gains**, and that is deliberate: bounding loads the legs quite
differently from the other three and needs its own tuning. Getting it to move is
part of Q4.1. The knob is the joint damping `kd`, and the useful window is narrower
than you would expect: too little and the robot shudders in place, too much and it
locks up and burns energy going nowhere. Change it one step at a time and watch the
Cost of Transport, not just the speed.

Then answer:

**Q4.1** Which gait has the lowest Cost of Transport, and which the highest? Compare
your numbers with the table in section 8.2.4. Where does the A1 sit relative to
ASIMO and to Cornell Ranger, and what does that tell you?

**Q4.2** Set `ADD_CARTESIAN_PD = False` and run TROT again. What changes, in the
foot-tracking plot and in the Cost of Transport? Why does the joint PD term alone
track the desired foot position less well?

**Q4.3** In `env/hopf_network.py`, set `couple=False` when constructing the
`HopfNetwork` and run TROT. The four oscillators now run independently. What
happens to the gait, and what does that tell you about where the gait is actually
stored?

---

## 4. Part 5: putting a policy on top

Now the policy chooses the amplitude µ and the frequency ω of each oscillator, eight
numbers per control step. It does not learn to walk from scratch: the CPG still
supplies the rhythm.

| TODO | File | What |
|---|---|---|
| 8 | `env/hopf_network.py` | the RL version of the integration |
| 9 | `env/quadruped_gym_env.py` | **your reward function** |
| 10 | `env/quadruped_gym_env.py` | port your Part 4 mapping into the environment |
| 11–13 | `load_sb3.py` | evaluation logging and plots |

**Q5.1 — before you write any code.** Open `_get_observation()` in
`env/quadruped_gym_env.py` and read the observation you have been given. For each
block, decide whether it is something you could actually measure on a real A1. One
of them is not honestly measurable. Which, why, and what would you do about it?
Section 8.3.4.3 is the relevant reading.

**TODO 9 — the reward.** This is where your time will go, and it is the whole point
of section 8.3.4.1. Suggested terms are listed in the docstring. Two warnings:

- The optimiser maximises exactly what you write, not what you meant. If you reward
  forward velocity and nothing else, expect the robot to discover that falling
  forwards scores well.
- Keep the total reward positive. If it can go negative, ending the episode early
  becomes a good strategy, and the policy will learn to fall over deliberately.

**Training.** `run_sb3.py` is already configured: PPO, 6 parallel environments,
250 000 steps, roughly 20–40 minutes on a laptop. You are not trying to produce a
polished gait in that budget. You are looking for a reward curve that rises and a
robot that ends up moving forward.

```bash
python run_sb3.py     # trains, prints where it saved
python load_sb3.py    # set LOG_DIR to that path first
```

If the reward curve is flat after 250k steps, the problem is almost always the
reward function, not the training length. Go back to TODO 9.

### What to hand in for Part 5

**Q5.2** Give your reward function and explain each term in one sentence. Which
weight did you have most trouble with, and what did the robot do when it was wrong?

**Q5.3** Compare the learned controller with your best hand-tuned CPG from Part 4,
on the same two numbers: average speed and Cost of Transport. Which wins, and is the
comparison fair?

**Q5.4** Look at the contact diagram from TODO 13. Which gait did the policy settle
on? Is it one of the four you built in Part 4, or something in between?

**Q5.5** In `load_sb3.py`, set `add_noise` to `True` and run the evaluation again.
This is noise the policy never saw during training. What happens, and what does that
suggest about the sim-to-real transfer of this controller?

**Q5.6** CPG-RL trains in a few hundred thousand steps. End-to-end RL on the same
robot typically needs tens of millions. Explain the difference in terms of what each
approach has to discover, and connect it to the hybrid architectures in section
8.3.6.

---

## 5. Credits

The simulation environment, the A1 model and the CPG formulation are adapted from
the *Legged Robots* course at EPFL, by **Prof. Auke Ijspeert** and
**Dr. Guillaume Bellegarda**, and are used here under the BSD 3-Clause licence.
The full licence text is reproduced at the top of `env/hopf_network.py`.

The CPG-RL formulation is from:

> G. Bellegarda and A. Ijspeert, "CPG-RL: Learning Central Pattern Generators for
> Quadruped Locomotion", *IEEE Robotics and Automation Letters*, 2022.
> https://doi.org/10.1109/LRA.2022.3218167

Reinforcement learning uses [stable-baselines3](https://stable-baselines3.readthedocs.io).
