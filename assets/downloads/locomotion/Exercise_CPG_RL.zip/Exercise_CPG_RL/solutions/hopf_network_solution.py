# SPDX-FileCopyrightText: Copyright (c) 2022 Guillaume Bellegarda. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2022 EPFL, Guillaume Bellegarda

"""
REFERENCE SOLUTION for Part 4, and for TODO 8 of Part 5.

CPG in polar coordinates, based on:

  CPG-RL: Learning Central Pattern Generators for Quadruped Locomotion
  G. Bellegarda and A. Ijspeert, IEEE RA-L 2022
  https://ieeexplore.ieee.org/abstract/document/9932888

Each leg is driven by one Hopf oscillator with an amplitude r and a phase theta.
The oscillators are coupled to one another, and it is the coupling that fixes the
phase relationships between the legs, i.e. the gait.
"""

import numpy as np

# for RL: the policy sets amplitudes inside this range
MU_LOW = 1
MU_UPP = 2


class HopfNetwork():
  """ CPG network based on Hopf polar equations, mapped to foot positions in Cartesian space.

  Foot order is FR, FL, RR, RL
  (Front Right, Front Left, Rear Right, Rear Left)
  """

  def __init__(self,
               mu=1**2,                  # intrinsic amplitude, r converges to sqrt(mu)
               omega_swing=4*2*np.pi,    # frequency during swing (rad/s)
               omega_stance=2*2*np.pi,   # frequency during stance (rad/s)
               gait="TROT",              # TROT, WALK, PACE or BOUND
               alpha=50,                 # amplitude convergence factor
               coupling_strength=1,      # coefficient multiplying the coupling matrix
               couple=True,              # whether oscillators are coupled at all
               time_step=0.001,          # integration time step (s)
               ground_clearance=0.07,    # foot swing height (m)
               ground_penetration=0.01,  # foot stance penetration into the ground (m)
               robot_height=0.3,         # nominal standing height (m)
               des_step_len=0.1,         # desired step length (m)
               max_step_len_rl=0.1,      # max step length, for RL scaling (m)
               use_RL=False,             # whether the parameters come from an RL policy
               seed=0                    # fixes the random initial amplitudes
               ):

    # CPG state: row 0 holds the four amplitudes r, row 1 holds the four phases theta
    self.X = np.zeros((2, 4))
    self.X_dot = np.zeros((2, 4))

    # save parameters
    self._mu = mu
    self._omega_swing = omega_swing
    self._omega_stance = omega_stance
    self._alpha = alpha
    self._couple = couple
    self._coupling_strength = coupling_strength
    self._dt = time_step
    self._set_gait(gait)

    # Oscillator initial conditions. The amplitudes start small and far from the
    # limit cycle, so that you can watch them converge to sqrt(mu) in the plots.
    # The seed keeps that start fixed, so two runs of the same code give the same
    # result and you can actually compare gaits and gains.
    rng = np.random.default_rng(seed)
    self.X[0, :] = rng.random(4) * .1
    self.X[1, :] = self.PHI[0, :]

    # body and foot shaping
    self._ground_clearance = ground_clearance
    self._ground_penetration = ground_penetration
    self._robot_height = robot_height
    self._des_step_len = des_step_len

    # for RL
    self.use_RL = use_RL
    self._omega_rl = np.zeros(4)
    self._mu_rl = np.zeros(4)
    self._max_step_len_rl = max_step_len_rl
    if use_RL:
      self.X[0, :] = MU_LOW

  def _set_gait(self, gait):
    """ Coupling matrices, one per gait.

    PHI[i][j] is the phase offset that oscillator i should keep relative to
    oscillator j. The coupling term you will write in TODO 2c drives

        theta_j - theta_i - PHI[i][j]   ->   0

    so for the network to settle on the gait you want, the matrix must be

        PHI[i][j] = theta_j_desired - theta_i_desired

    Mind that sign. Three of the four gaits below use offsets of 0 or +/- pi only,
    where sin() cannot tell the two sign conventions apart, so they will look correct
    either way. WALK is the one that will catch you: get the sign backwards and it
    still walks, but with the footfall sequence running in the wrong order.

    Foot order is FR, FL, RR, RL. The desired phases of the four legs are:

        gait    FR      FL      RR       RL
        ----    ----    ----    -----    ----
        TROT    0       pi      pi       0
        PACE    0       pi      0        pi
        BOUND   0       0       pi       pi
        WALK    0       pi      3*pi/2   pi/2

    SOLUTION: each matrix below is PHI[i][j] = theta_j - theta_i, read straight off
    the table. Every one of them is antisymmetric, which is the quick sanity check.
    """
    pi = np.pi

    # TROT  : theta = [0, pi, pi, 0]      diagonal pairs move together
    self.PHI_trot = np.array([[0,   pi,  pi,   0],
                              [-pi,  0,   0, -pi],
                              [-pi,  0,   0, -pi],
                              [0,   pi,  pi,   0]])

    # WALK  : theta = [0, pi, 3*pi/2, pi/2]   one foot off the ground at a time
    self.PHI_walk = np.array([[0,        pi,  3*pi/2,  pi/2],
                              [-pi,       0,    pi/2, -pi/2],
                              [-3*pi/2, -pi/2,     0,   -pi],
                              [-pi/2,    pi/2,    pi,     0]])

    # BOUND : theta = [0, 0, pi, pi]      front pair, then rear pair
    self.PHI_bound = np.array([[0,    0,  pi,  pi],
                               [0,    0,  pi,  pi],
                               [-pi, -pi,  0,   0],
                               [-pi, -pi,  0,   0]])

    # PACE  : theta = [0, pi, 0, pi]      left pair, then right pair
    self.PHI_pace = np.array([[0,   pi,   0,  pi],
                              [-pi,  0, -pi,   0],
                              [0,   pi,   0,  pi],
                              [-pi,  0, -pi,   0]])

    if gait == "TROT":
      self.PHI = self.PHI_trot
    elif gait == "PACE":
      self.PHI = self.PHI_pace
    elif gait == "BOUND":
      self.PHI = self.PHI_bound
    elif gait == "WALK":
      self.PHI = self.PHI_walk
    else:
      raise ValueError(gait + ' not implemented.')

  def update(self):
    """ Integrate the oscillators one step, then map their state to foot positions.

    Returns the desired foot x and z positions in the leg frame, as two arrays of
    length 4 (one entry per leg).
    """
    if not self.use_RL:
      self._integrate_hopf_equations()
    else:
      self._integrate_hopf_equations_rl()

    x = np.zeros(4)
    z = np.zeros(4)

    if not self.use_RL:
      # SOLUTION
      for i in range(4):
        r_i = self.get_r()[i]
        theta_i = self.get_theta()[i]

        x[i] = -self._des_step_len * r_i * np.cos(theta_i)

        if np.sin(theta_i) > 0:   # swing: lift the foot clear of the ground
          z[i] = -self._robot_height + self._ground_clearance * np.sin(theta_i)
        else:                     # stance: press slightly into the ground
          z[i] = -self._robot_height + self._ground_penetration * np.sin(theta_i)

      return x, z

    else:
      # For RL the amplitude sets the step length, so it is clipped to the range the
      # policy is allowed to command.
      r = np.clip(self.X[0, :], MU_LOW, MU_UPP)

      for i in range(4):
        theta_i = self.get_theta()[i]
        if np.sin(theta_i) > 0:
          z[i] = -self._robot_height + self._ground_clearance * np.sin(theta_i)
        else:
          z[i] = -self._robot_height + self._ground_penetration * np.sin(theta_i)

      return -self._max_step_len_rl * (r - MU_LOW) * np.cos(self.X[1, :]), z

  def _integrate_hopf_equations(self):
    """ Hopf polar equations, and their integration. """
    # bookkeeping: keep copies of the current state and the previous derivative
    X = self.X.copy()
    X_dot_prev = self.X_dot.copy()
    X_dot = np.zeros((2, 4))

    for i in range(4):
      r, theta = X[0, i], X[1, i]

      # SOLUTION: amplitude converges to sqrt(mu)
      r_dot = self._alpha * (self._mu - r ** 2) * r

      # SOLUTION: swing while sin(theta) > 0, stance otherwise
      if np.sin(theta) > 0:
        omega_i = self._omega_swing
      else:
        omega_i = self._omega_stance

      theta_dot = omega_i

      # SOLUTION: coupling pulls the network onto the phase offsets stored in PHI
      if self._couple:
        for j in range(4):
          if j != i:
            r_j = X[0, j]
            theta_j = X[1, j]
            theta_dot += r_j * self._coupling_strength * np.sin(theta_j - theta - self.PHI[i][j])

      X_dot[:, i] = [r_dot, theta_dot]

    # SOLUTION: trapezoidal integration
    self.X = X + (X_dot_prev + X_dot) * self._dt / 2
    self.X_dot = X_dot

    # keep the phases in [0, 2*pi)
    self.X[1, :] = self.X[1, :] % (2 * np.pi)

  ##################################################################################
  # Helper functions for accessing CPG states
  ##################################################################################
  def get_r(self):
    """ CPG amplitudes r """
    return self.X[0, :]

  def get_theta(self):
    """ CPG phases theta """
    return self.X[1, :]

  def get_dr(self):
    """ CPG amplitude derivatives r_dot """
    return self.X_dot[0, :]

  def get_dtheta(self):
    """ CPG phase derivatives theta_dot """
    return self.X_dot[1, :]

  ##################################################################################
  # Functions for setting parameters from RL (used in Part 5)
  ##################################################################################
  def set_omega_rl(self, omegas):
    """ Set intrinsic frequencies. """
    self._omega_rl = omegas

  def set_mu_rl(self, mus):
    """ Set intrinsic amplitude setpoints. """
    self._mu_rl = mus

  def _integrate_hopf_equations_rl(self):
    """ Same equations, but with mu and omega supplied by the RL policy.

SOLUTION: identical to _integrate_hopf_equations, except that the amplitude
    setpoint and the frequency both come from the policy instead of from fixed
    parameters. The coupling term is unchanged, which is the point: the policy
    modulates the rhythm, it does not replace it.
    """
    X = self.X.copy()
    X_dot_prev = self.X_dot.copy()
    X_dot = np.zeros((2, 4))

    for i in range(4):
      r, theta = X[:, i]

      r_dot = self._alpha * (self._mu_rl[i] - r ** 2) * r
      theta_dot = self._omega_rl[i]

      if self._couple:
        for j in range(4):
          if j != i:
            r_j = X[0, j]
            theta_j = X[1, j]
            theta_dot += r_j * self._coupling_strength * np.sin(theta_j - theta - self.PHI[i][j])

      X_dot[:, i] = [r_dot, theta_dot]

    self.X = X + (X_dot_prev + X_dot) * self._dt / 2
    self.X_dot = X_dot
    self.X[1, :] = self.X[1, :] % (2 * np.pi)
