"""
REFERENCE SOLUTION for Part 5, TODO 9 and TODO 10.

Only two small regions of env/quadruped_gym_env.py change, so rather than ship a
near-duplicate of a 700-line file, the two methods are reproduced here in full.
Copy each one over the corresponding method in env/quadruped_gym_env.py.

Note on TODO 9: there is no single correct reward. What follows is *a* reward that
trains reliably within the budget suggested in the handout. Yours may look quite
different and still be better. What matters is that you can explain why each term
is there, and what the robot did when you got a weight wrong.
"""

import numpy as np


# ==================================================================================
# TODO 9 -- goes in place of _reward_lr_course() in env/quadruped_gym_env.py
# ==================================================================================
def _reward_lr_course(self, des_vel_x=1.0):
    """ Track a desired forward velocity, stay upright, go straight, spend little.

    Each term below answers one question:

      velocity   are we moving at the speed we were asked for?
      lateral    are we drifting sideways?
      attitude   are we staying level and pointing straight ahead?
      energy     are we paying too much for it?

    The velocity term uses a Gaussian rather than a bare +vx. A bare +vx rewards
    "faster is always better", so the policy learns to sprint and the des_vel_x
    command stops meaning anything. The Gaussian peaks exactly at the commanded
    speed, so overshooting is penalised just like undershooting.
    """
    vx, vy, _ = self.robot.GetBaseLinearVelocity()
    roll, pitch, yaw = self.robot.GetBaseOrientationRollPitchYaw()

    # --- velocity tracking: peaks at des_vel_x, falls off either side -------------
    vel_reward = 1.0 * np.exp(-((vx - des_vel_x) ** 2) / 0.25)

    # --- do not drift sideways ----------------------------------------------------
    lateral_penalty = 0.10 * vy ** 2

    # --- stay level and go straight -----------------------------------------------
    attitude_penalty = 0.05 * (abs(roll) + abs(pitch)) + 0.10 * abs(yaw)

    # --- energy: integrate |tau . omega| over the substeps of this control step ----
    energy = 0.0
    for tau, vel in zip(self._dt_motor_torques, self._dt_motor_velocities):
        energy += np.abs(np.dot(tau, vel)) * self._time_step
    energy_penalty = 0.002 * energy

    reward = vel_reward - lateral_penalty - attitude_penalty - energy_penalty

    return max(reward, 0)  # keep rewards positive


# ==================================================================================
# TODO 10 -- the leg loop inside ScaleActionToCPGStateModulations()
# ==================================================================================
#
# Replace the two [TODO 10a] / [TODO 10b] lines with the following. This is the
# same mapping as Part 4, only now kp and kd are 12-vectors, so they are indexed
# per leg.
#
#       # SOLUTION 10a: inverse kinematics for the desired joint angles
#       q_des = self.robot.ComputeInverseKinematics(i, [x, y, z])
#
#       # SOLUTION 10b: joint PD, desired joint velocity is zero
#       tau = (kp[3*i:3*i+3] * (q_des - q[3*i:3*i+3])
#              + kd[3*i:3*i+3] * (0 - dq[3*i:3*i+3]))
#
#       # OPTIONAL: add the Cartesian PD term from Part 4 on top. It usually makes
#       # tracking crisper, at the cost of a little more computation per step.
#       # J, foot_pos = self.robot.ComputeJacobianAndPosition(i, q[3*i:3*i+3])
#       # foot_vel = J @ dq[3*i:3*i+3]
#       # kpC = self._robot_config.kpCartesian
#       # kdC = self._robot_config.kdCartesian
#       # tau += J.T @ (kpC @ (np.array([x, y, z]) - foot_pos) + kdC @ (-foot_vel))
#
# ==================================================================================


# ==================================================================================
# Notes on Question 5.1 (which observations are honest?)
# ==================================================================================
#
# The observation vector you were given contains, in order:
#
#   contact booleans (4)      measurable      foot contact switches exist on the A1
#   joint angles (12)         measurable      joint encoders
#   joint velocities (12)     measurable      differentiated encoders, noisy but fine
#   base orientation (4)      measurable      IMU, as a quaternion
#   base linear velocity (3)  NOT directly    this is the problem one
#   base angular velocity (3) measurable      IMU gyroscope
#   CPG r, dr, theta, dtheta  free            these are internal controller states,
#                                             so they cost nothing to "measure"
#
# Base *linear* velocity is the one to flag. Nothing on the robot measures it. It
# has to be reconstructed by a state estimator that fuses IMU acceleration with leg
# odometry, and it drifts, especially when feet slip. A policy that leans on it in
# simulation, where it is exact and free, can degrade badly on hardware. This is the
# reality gap of section 8.3.4.3 in its most concrete form.
#
# The usual fixes: drop it and let the policy infer speed from a history of joint
# states and contacts; or keep it but add noise and delay during training so the
# policy never learns to trust it too much.
#
# Note also the last block: the CPG states are free observations. The controller
# already knows its own phase and amplitude. That is a quiet argument for the hybrid
# architecture of section 8.3.6 -- the CPG gives the policy a clean, noiseless
# description of where it is in the gait cycle, which no sensor would have provided.
