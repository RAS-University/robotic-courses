# SPDX-FileCopyrightText: Copyright (c) 2022 Guillaume Bellegarda. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the conditions of the BSD 3-Clause license are met.
# The full licence text is reproduced in env/hopf_network.py.
#
# Copyright (c) 2022 EPFL, Guillaume Bellegarda

"""
REFERENCE SOLUTION for Part 5.

PART 5: load a trained policy and see what it learned.

Set LOG_DIR below to the folder run_sb3.py printed when it finished, then run:

    python load_sb3.py

The numbers printed at the end are the ones to compare against Part 4: average
speed and Cost of Transport, measured the same way, so the comparison is fair.
"""

import os
import numpy as np
from matplotlib import pyplot as plt

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_util import make_vec_env

from utils.file_utils import get_latest_model
from env.quadruped_gym_env import QuadrupedGymEnv

# ----------------------------------------------------------------------------------
# SOLUTION 11: point this at your own training run. If you have several, this
# picks the most recent one automatically.
import glob
_runs = sorted(glob.glob('./logs/intermediate_models/*/'))
LOG_DIR = _runs[-1] if _runs else './logs/intermediate_models/REPLACE_ME/'
# ----------------------------------------------------------------------------------

TEST_STEPS = 2000
DES_VEL_X = 1.0   # the velocity you trained for, used for the tracking plot

env_config = {"motor_control_mode": "CPG",
              "task_env": "LR_COURSE_TASK",
              "observation_space_mode": "LR_COURSE_OBS",
              "render": True,
              "record_video": False,
              "add_noise": False}   # try True once it works: noise it never saw

if not os.path.isdir(LOG_DIR):
    raise SystemExit(f"LOG_DIR does not exist: {LOG_DIR}\n"
                     f"Set it to the folder printed by run_sb3.py (TODO 11).")

stats_path = os.path.join(LOG_DIR, "vec_normalize.pkl")
model_name = get_latest_model(LOG_DIR)

env = lambda: QuadrupedGymEnv(**env_config)
env = make_vec_env(env, n_envs=1)
env = VecNormalize.load(stats_path, env)
env.training = False     # do not update normalisation statistics at test time
env.norm_reward = False

model = PPO.load(model_name, env)
print("\nLoaded", model_name, "\n")

# ----------------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------------
speed_log = np.zeros(TEST_STEPS)
reward_log = np.zeros(TEST_STEPS)
r_log = np.zeros((TEST_STEPS, 4))
theta_log = np.zeros((TEST_STEPS, 4))
mu_rl_log = np.zeros((TEST_STEPS, 4))
omega_rl_log = np.zeros((TEST_STEPS, 4))
contact_log = np.zeros((TEST_STEPS, 4))
energy = 0.0

obs = env.reset()
episode_reward = 0

for i in range(TEST_STEPS):
    action, _ = model.predict(obs, deterministic=True)
    obs, rewards, dones, info = env.step(action)
    episode_reward += rewards

    base_env = env.envs[0].env
    cpg = base_env._cpg

    # SOLUTION 12
    v = base_env.robot.GetBaseLinearVelocity()
    speed_log[i] = np.sqrt(v[0] ** 2 + v[1] ** 2)
    reward_log[i] = rewards[0]
    r_log[i, :] = cpg.get_r()
    theta_log[i, :] = cpg.get_theta()
    mu_rl_log[i, :] = cpg._mu_rl
    omega_rl_log[i, :] = cpg._omega_rl
    contact_log[i, :] = base_env.robot.GetContactInfo()[3]

    for tau, vel in zip(base_env._dt_motor_torques, base_env._dt_motor_velocities):
        energy += np.abs(np.dot(tau, vel)) * base_env._time_step

    if dones:
        print("episode reward", episode_reward, " final base position", info[0]['base_pos'])
        episode_reward = 0
        obs = env.reset()

# ----------------------------------------------------------------------------------
# Results
# ----------------------------------------------------------------------------------
base_pos = env.envs[0].env.robot.GetBasePosition()
distance = np.sqrt(base_pos[0] ** 2 + base_pos[1] ** 2)
mass = sum(env.envs[0].env.robot.GetTotalMassFromURDF())
cot = energy / (mass * 9.81 * distance) if distance > 1e-6 else float('nan')

print("\n" + "=" * 52)
print(f" average speed       {np.mean(speed_log):.3f} m/s   (target {DES_VEL_X})")
print(f" distance travelled  {distance:.2f} m")
print(f" Cost of Transport   {cot:.3f}")
print("=" * 52 + "\n")

# SOLUTION 13
dt = env.envs[0].env._time_step * env.envs[0].env._action_repeat
t = np.arange(TEST_STEPS) * dt
legs = ["FR", "FL", "RR", "RL"]

fig, ax = plt.subplots(2, 2, figsize=(13, 7))

ax[0, 0].plot(t, speed_log, label="measured")
ax[0, 0].axhline(DES_VEL_X, color='k', ls='--', label="commanded")
ax[0, 0].set_title("Base speed tracking")
ax[0, 0].set_xlabel("time (s)"); ax[0, 0].set_ylabel("speed (m/s)")
ax[0, 0].legend(fontsize=8)

ax[0, 1].plot(t, mu_rl_log)
ax[0, 1].set_title(r"Amplitudes $\mu$ commanded by the policy")
ax[0, 1].set_xlabel("time (s)")
ax[0, 1].legend(legs, fontsize=8, loc="upper right")

ax[1, 0].plot(t, omega_rl_log)
ax[1, 0].set_title(r"Frequencies $\omega$ commanded by the policy (rad/s)")
ax[1, 0].set_xlabel("time (s)")
ax[1, 0].legend(legs, fontsize=8, loc="upper right")

ax[1, 1].imshow(contact_log.T, aspect='auto', cmap='Greys', interpolation='nearest',
                extent=[0, t[-1], 3.5, -0.5])
ax[1, 1].set_yticks(range(4)); ax[1, 1].set_yticklabels(legs)
ax[1, 1].set_title("Contact diagram (dark = foot on the ground)")
ax[1, 1].set_xlabel("time (s)")

fig.suptitle(f"Learned CPG modulation, mean speed {np.mean(speed_log):.2f} m/s, CoT {cot:.3f}")
fig.tight_layout()
plt.show()
