# SPDX-FileCopyrightText: Copyright (c) 2022 Guillaume Bellegarda. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the conditions of the BSD 3-Clause license are met.
# The full licence text is reproduced in env/hopf_network.py.
#
# Copyright (c) 2022 EPFL, Guillaume Bellegarda

"""
PART 5: train a policy to modulate the CPG.

The policy does not learn to walk from scratch. The CPG from Part 4 already produces
a rhythm; the policy only chooses, at every control step, the amplitude mu and the
frequency omega of each of the four oscillators. That is 8 numbers.

This is why CPG-RL trains so much faster than end-to-end RL: the hard part, the
periodic structure of the gait, is supplied by the model rather than discovered.
Watch for that when your reward curve starts rising.

Before running this you need:
  - Part 4 working (the CPG itself)
  - TODO 8  in env/hopf_network.py      (the RL integration)
  - TODO 9  in env/quadruped_gym_env.py (your reward)
  - TODO 10 in env/quadruped_gym_env.py (CPG -> torque mapping)

Run with:  python run_sb3.py
Then evaluate what you trained with:  python load_sb3.py
"""

import os
from datetime import datetime

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import VecNormalize, SubprocVecEnv
from stable_baselines3.common.env_util import make_vec_env

from utils.utils import CheckpointCallback
from env.quadruped_gym_env import QuadrupedGymEnv

# ----------------------------------------------------------------------------------
# Training budget
# ----------------------------------------------------------------------------------
# 250k steps with 6 parallel environments is roughly 20-40 minutes on a laptop CPU.
# You are NOT trying to produce a polished gait in that time. You are looking for
# two things: a reward curve that rises, and a robot that ends up moving forward.
# If you have time to spare afterwards, raise TOTAL_TIMESTEPS and run it again.
TOTAL_TIMESTEPS = 250_000
NUM_ENVS = 6           # raise if you have more cores, lower if your machine struggles

env_configs = {"motor_control_mode": "CPG",
               "task_env": "LR_COURSE_TASK",
               "observation_space_mode": "LR_COURSE_OBS"}

SAVE_PATH = './logs/intermediate_models/' + datetime.now().strftime("%m%d%y%H%M%S") + '/'
os.makedirs(SAVE_PATH, exist_ok=True)

checkpoint_callback = CheckpointCallback(save_freq=30000, save_path=SAVE_PATH,
                                         name_prefix='rl_model', verbose=2)


def main():
    env = lambda: QuadrupedGymEnv(**env_configs)
    env = make_vec_env(env, monitor_dir=SAVE_PATH, n_envs=NUM_ENVS,
                       vec_env_cls=SubprocVecEnv)

    # Normalising observations keeps learning stable when the entries have wildly
    # different scales, which they do here: joint angles are order 1, joint
    # velocities order 10, CPG frequencies order 30.
    env = VecNormalize(env, norm_obs=True, norm_reward=False, clip_obs=100.)

    policy_kwargs = dict(net_arch=[256, 256])

    model = PPO('MlpPolicy', env, verbose=1,
                gamma=0.99,
                n_steps=int(4096 / NUM_ENVS),
                ent_coef=0.01,
                learning_rate=lambda f: 1e-4,
                vf_coef=0.5,
                max_grad_norm=0.5,
                gae_lambda=0.95,
                batch_size=128,
                n_epochs=10,
                clip_range=0.2,
                clip_range_vf=1,
                policy_kwargs=policy_kwargs,
                device='cpu')

    print(f"\nTraining for {TOTAL_TIMESTEPS} steps in {NUM_ENVS} parallel envs.")
    print(f"Saving to {SAVE_PATH}\n")

    model.learn(total_timesteps=TOTAL_TIMESTEPS, log_interval=1,
                callback=checkpoint_callback)

    # both the weights and the observation normalisation statistics are needed at
    # test time, so save them together
    model.save(os.path.join(SAVE_PATH, "rl_model"))
    env.save(os.path.join(SAVE_PATH, "vec_normalize.pkl"))

    print(f"\nDone. Set LOG_DIR in load_sb3.py to:\n  {SAVE_PATH}\n")


if __name__ == "__main__":
    main()
